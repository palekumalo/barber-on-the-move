import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { EditApointmentPage } from './edit-apointment.page';

describe('EditApointmentPage', () => {
  let component: EditApointmentPage;
  let fixture: ComponentFixture<EditApointmentPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditApointmentPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(EditApointmentPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
