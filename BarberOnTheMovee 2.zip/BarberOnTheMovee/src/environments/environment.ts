// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCvZLo3mfJwIWeLeRApJV2MclZyOfsnGm0",
    authDomain: "barberonthemove-db4cc.firebaseapp.com",
    databaseURL: "https://barberonthemove-db4cc-default-rtdb.firebaseio.com",
    projectId: "barberonthemove-db4cc",
    storageBucket: "barberonthemove-db4cc.appspot.com",
    messagingSenderId: "552536187383",
    appId: "1:552536187383:web:722c231b1e8aeb50960ef2",
    measurementId: "G-6HBJY9S43S"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
