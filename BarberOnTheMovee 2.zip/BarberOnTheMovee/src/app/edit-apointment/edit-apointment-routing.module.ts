import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EditApointmentPage } from './edit-apointment.page';

const routes: Routes = [
  {
    path: '',
    component: EditApointmentPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EditApointmentPageRoutingModule {}
