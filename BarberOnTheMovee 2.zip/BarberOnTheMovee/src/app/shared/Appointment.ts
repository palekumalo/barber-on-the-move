export class Appointment {
    $key: string;
    name: string;
    email: string
    mobile: number;
    serviceType: string;
    address: string;
    date: string;
}